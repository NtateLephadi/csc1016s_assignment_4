/* Tumelo Lephadi
   Manipulates Currency object variables which it returns
   20 August 2015
*/

class Money{
   
   private Currency currency;
   private long minorUnitAmount;
   
   public Money(String amount, Currency currency){
      this.currency = currency;
      minorUnitAmount = currency.parse(amount); 
   }
   public Money(long minorUnitAmount, Currency currency){
      this.minorUnitAmount = minorUnitAmount;
      this.currency = currency;
   }
   public long longAmount(){
      return minorUnitAmount;
   }   
   public Currency currency(){
      return currency;
   }
   public Money add(Money other){
      return new Money(other.longAmount() + minorUnitAmount, currency);
   }
   public Money subtract(Money other){
      return new Money(minorUnitAmount - other.longAmount(), currency);
   }
   public String toString(){
      return this.currency.format(minorUnitAmount);
   }
}