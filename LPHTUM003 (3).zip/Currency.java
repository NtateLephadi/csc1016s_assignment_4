/* Tumelo Lephadi
   Program that provides facilities for creating strings and for interpreting strings that represent amounts of the currency
   18 August 2015
*/

class Currency{
   
   private String symbol;
   private String code;
   private int minorPerMajor;
   
   public Currency(String symbol, String code, int minorPerMajor){
      /* Create a Currency object that represents the currency with the given unit symbol
         ISO 4217 code, and number of minor units per major units(e.g. 100 in case of pennies per British Pound
      */
      this.symbol = symbol;
      this.code = code;
      this.minorPerMajor = minorPerMajor;
   }
   
   public String symbol(){
      // Obtain the symbol sign for this currency.
      return this.symbol;
   }
   
   public String code(){
      // Obtain the ISO 4217 code for this currency.
      return this.code;
   }
   
   public int minorPerMajor(){
      // Obtain the number of minor units per major e.g. there are 100 cents in the Euro.
      return this.minorPerMajor;
   }   
   
   public String format(long amount){
      // Obtain a string representation of the amount given.
      // The amount is assumed to be in the currency's minor unit e.g. pennies for Stering, cents for Rand. 
      if (amount < 0){
         return "-" + symbol() + String.format("%.2f", ((double) amount*(-1)/minorPerMajor()));   
      }
      else{
         return "" + symbol() + String.format("%.2f", ((double) amount/minorPerMajor()));
      }
   }
   
   public long parse(String amount){
      // Obtain a numerical value for the quantity represented by the given string.
      //The result is given as a quantity of the currency's minor unit.
      //The String is assumed to have the format [-]<symbol><quantity of units><quantity of minor units>
      //(The square brackets indicate that the minus sign is optional)
      if (amount.charAt(0) == '-'){
         double moola = Double.parseDouble(amount.substring(2, amount.length()));
         double moola1 = (-1) * moola * minorPerMajor();
         return (long) moola1;
      }
      else{
         double moola = Double.parseDouble(amount.substring(1));
         double moola1 = moola * minorPerMajor();
         return (long) moola1;
      }   
   }
}